package youOjdbc;

public class ojdbcMain {

	public static void main(String[] args) {
		 ojdbc.DBConnect();
		 

	}

}
